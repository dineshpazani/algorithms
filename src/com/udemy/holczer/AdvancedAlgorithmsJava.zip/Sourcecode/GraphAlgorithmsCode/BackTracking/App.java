package BackTracking;

public class App {

	public static void main(String[] args) {
		
		QueensProblem queensProblem = new QueensProblem(4);
		queensProblem.solveQueensProblem();
        
	}
}

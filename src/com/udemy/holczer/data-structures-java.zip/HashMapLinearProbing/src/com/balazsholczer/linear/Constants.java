package com.balazsholczer.linear;

public class Constants {

	private Constants() {
		
	}
	
	public static final int TABLE_SIZE = 10;
}

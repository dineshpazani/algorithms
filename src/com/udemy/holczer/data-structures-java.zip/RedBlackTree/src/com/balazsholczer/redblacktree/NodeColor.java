package com.balazsholczer.redblacktree;

public enum NodeColor {

	RED, BLACK;
}

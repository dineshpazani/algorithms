from pybrain.tools.shortcuts import buildNetwork
from pybrain.structure.modules import TanhLayer
from pybrain.structure.modules import SoftmaxLayer

#			BASIC TOPOLOGY IN PYBRAIN !!!
#	Installing pybrain -> I was failed to install it via pip,
#		so I downloaded the .zip file + install pybrain manually
#

